/*
 * Temporia avatar renderer - classic Roblox R6 rig in WebGL, no libraries.
 *
 *  - Stud-correct R6 body: Head 2x1x1, Torso 2x2x1, Arms/Legs 1x2x1
 *  - Shirts / pants use the standard 585x559 Roblox clothing template layout, T-shirts are a torso-front decal
 *  - Faces are decals on the head's front side
 *  - Accessories are .obj meshes (auto-centred + auto-scaled, with optional per-item offset / scale / rotation)
 *
 *  API
 *    var r = AvatarRenderer.create(canvas);       // interactive renderer on a canvas
 *    r.set(outfit).then(function(){ r.draw(); })  // load textures + meshes
 *    AvatarRenderer.thumb(outfit, {w,h,mode})     // -> Promise<dataURL>  (shared offscreen renderer)
 *    AvatarRenderer.outfit(colors, wornItems)     // build an outfit from API data
 */
(function (global) {
  'use strict';

  var DEFAULT_COLORS = { head: '#f5cd30', torso: '#0d69ac', leftArm: '#f5cd30', rightArm: '#f5cd30', leftLeg: '#a4bd47', rightLeg: '#a4bd47' };
  var PALETTE = ['#f2f3f3', '#e5e4df', '#a3a2a5', '#635f62', '#1b2a35', '#c4281c', '#da8541', '#f5cd30', '#fdea8d', '#a4bd47', '#4b974b', '#287f47',
    '#0d69ac', '#6e99ca', '#04afec', '#203a56', '#6b327c', '#e8bac8', '#d7c59a', '#cc8e69', '#a05f35', '#694028', '#ffcc99', '#74869d'];

  /* ---- Roblox classic clothing template (585 x 559): [x, y, w, h] in pixels ---- */
  var TW = 585, TH = 559;
  var UV_TORSO = { top: [231, 8, 128, 64], bottom: [231, 204, 128, 64], right: [165, 74, 64, 128], front: [231, 74, 128, 128], left: [361, 74, 64, 128], back: [427, 74, 128, 128] };
  var UV_RLIMB = { top: [217, 289, 64, 64], bottom: [217, 483, 64, 64], right: [19, 355, 64, 128], back: [85, 355, 64, 128], left: [151, 355, 64, 128], front: [217, 355, 64, 128] };
  var UV_LLIMB = { top: [308, 289, 64, 64], bottom: [308, 483, 64, 64], front: [308, 355, 64, 128], right: [374, 355, 64, 128], back: [440, 355, 64, 128], left: [506, 355, 64, 128] };
  var HEAD_TW = 256, HEAD_TH = 128;
  var UV_HEAD = { front: [0, 0, 128, 128], back: [128, 0, 128, 128], right: [128, 0, 128, 128], left: [128, 0, 128, 128], top: [128, 0, 128, 128], bottom: [128, 0, 128, 128] };

  /* part: size (studs), centre, uv layout, clothing layers */
  var PARTS = [
    { id: 'rightLeg', size: [1, 2, 1], pos: [0.5, 1, 0], uv: UV_RLIMB, layers: ['pants'] },
    { id: 'leftLeg', size: [1, 2, 1], pos: [-0.5, 1, 0], uv: UV_LLIMB, layers: ['pants'] },
    { id: 'torso', size: [2, 2, 1], pos: [0, 3, 0], uv: UV_TORSO, layers: ['pants', 'shirt', 'tshirt'] },
    { id: 'rightArm', size: [1, 2, 1], pos: [1.5, 3, 0], uv: UV_RLIMB, layers: ['shirt'] },
    { id: 'leftArm', size: [1, 2, 1], pos: [-1.5, 3, 0], uv: UV_LLIMB, layers: ['shirt'] },
    { id: 'head', size: [2, 1, 1], pos: [0, 4.5, 0], uv: UV_HEAD, head: true }
  ];

  /* where each accessory type attaches (studs, avatar space; +X = character's right, front = -Z) */
  var ATTACH = {
    'Hat': [0, 5, 0], 'Hair': [0, 5, 0], 'Face Accessory': [0, 4.55, -0.55], 'Neck': [0, 4, 0], 'Shoulder': [1.5, 4, 0],
    'Front': [0, 3, -0.55], 'Back': [0, 3, 0.55], 'Waist': [0, 2, 0], 'Gear': [1.5, 2.4, -0.8]
  };
  var SIT_ON_BASE = { 'Hat': 1, 'Hair': 1 };   // bottom of the mesh sits on the attach point; others are centred

  /* ------------------------------------------------------------ matrices (column-major) */
  function ident() { return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }
  function mul(a, b) {
    var o = new Array(16);
    for (var c = 0; c < 4; c++) for (var r = 0; r < 4; r++) {
      var s = 0; for (var k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s;
    } return o;
  }
  function trans(x, y, z) { var m = ident(); m[12] = x; m[13] = y; m[14] = z; return m; }
  function scal(x, y, z) { var m = ident(); m[0] = x; m[5] = y; m[10] = z; return m; }
  function rotY(a) { var c = Math.cos(a), s = Math.sin(a), m = ident(); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; }
  function rotX(a) { var c = Math.cos(a), s = Math.sin(a), m = ident(); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; }
  function persp(fovy, asp, n, f) {
    var t = 1 / Math.tan(fovy / 2), m = new Array(16).fill(0);
    m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m;
  }
  function hexRGBA(h) { h = String(h || '#cccccc').replace('#', ''); if (h.length === 3) h = h.replace(/./g, '$&$&'); return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255, 1]; }

  /* ------------------------------------------------------------ loading helpers */
  var imgCache = {}, objCache = {};
  function loadImage(url) {
    if (!url) return Promise.resolve(null);
    if (!imgCache[url]) imgCache[url] = new Promise(function (ok) {
      var i = new Image(); i.onload = function () { ok(i); }; i.onerror = function () { ok(null); }; i.src = url;
    });
    return imgCache[url];
  }
  function loadOBJ(url) {
    if (!url) return Promise.resolve(null);
    if (!objCache[url]) objCache[url] = fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.ok ? r.text() : null; })
      .then(function (t) { return t ? parseOBJ(t) : null; }).catch(function () { return null; });
    return objCache[url];
  }
  function parseOBJ(text) {
    var v = [], vt = [], vn = [], pos = [], uv = [], nrm = [], lines = text.split('\n'), hasN = false;
    function idx(s, len) { var i = parseInt(s, 10); return i < 0 ? len + i : i - 1; }
    for (var li = 0; li < lines.length; li++) {
      var l = lines[li].trim(); if (!l || l[0] === '#') continue;
      var p = l.split(/\s+/), t = p[0];
      if (t === 'v') v.push([+p[1], +p[2], +p[3]]);
      else if (t === 'vt') vt.push([+p[1], +p[2]]);
      else if (t === 'vn') vn.push([+p[1], +p[2], +p[3]]);
      else if (t === 'f' && p.length >= 4) {
        var corners = [];
        for (var k = 1; k < p.length; k++) {
          var q = p[k].split('/');
          corners.push({ v: v[idx(q[0], v.length)], t: q[1] ? vt[idx(q[1], vt.length)] : null, n: q[2] ? vn[idx(q[2], vn.length)] : null });
        }
        for (var j = 1; j < corners.length - 1; j++) {
          var tri = [corners[0], corners[j], corners[j + 1]];
          if (!tri[0].v || !tri[1].v || !tri[2].v) continue;
          var a = tri[0].v, b = tri[1].v, c = tri[2].v;
          var ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], wx = c[0] - a[0], wy = c[1] - a[1], wz = c[2] - a[2];
          var fx = uy * wz - uz * wy, fy = uz * wx - ux * wz, fz = ux * wy - uy * wx, fl = Math.sqrt(fx * fx + fy * fy + fz * fz) || 1;
          for (var m = 0; m < 3; m++) {
            var cc = tri[m]; pos.push(cc.v[0], cc.v[1], cc.v[2]);
            uv.push(cc.t ? cc.t[0] : 0, cc.t ? 1 - cc.t[1] : 0);
            if (cc.n) { nrm.push(cc.n[0], cc.n[1], cc.n[2]); hasN = true; } else nrm.push(fx / fl, fy / fl, fz / fl);
          }
        }
      }
    }
    var min = [1e9, 1e9, 1e9], max = [-1e9, -1e9, -1e9];
    for (var i = 0; i < pos.length; i += 3) for (var d = 0; d < 3; d++) { if (pos[i + d] < min[d]) min[d] = pos[i + d]; if (pos[i + d] > max[d]) max[d] = pos[i + d]; }
    if (!pos.length) return null;
    return { pos: new Float32Array(pos), uv: new Float32Array(uv), nrm: new Float32Array(nrm), min: min, max: max };
  }

  function boxData(hx, hy, hz, uv, tw, th) {
    var F = [
      ['front', [0, 0, -1], [[hx, hy, -hz], [-hx, hy, -hz], [-hx, -hy, -hz], [hx, -hy, -hz]]],
      ['back', [0, 0, 1], [[-hx, hy, hz], [hx, hy, hz], [hx, -hy, hz], [-hx, -hy, hz]]],
      ['right', [1, 0, 0], [[hx, hy, hz], [hx, hy, -hz], [hx, -hy, -hz], [hx, -hy, hz]]],
      ['left', [-1, 0, 0], [[-hx, hy, -hz], [-hx, hy, hz], [-hx, -hy, hz], [-hx, -hy, -hz]]],
      ['top', [0, 1, 0], [[hx, hy, hz], [-hx, hy, hz], [-hx, hy, -hz], [hx, hy, -hz]]],
      ['bottom', [0, -1, 0], [[hx, -hy, -hz], [-hx, -hy, -hz], [-hx, -hy, hz], [hx, -hy, hz]]]
    ], pos = [], nrm = [], uvs = [], order = [0, 1, 2, 0, 2, 3];
    F.forEach(function (f) {
      var r = uv[f[0]], u0 = r[0] / tw, v0 = r[1] / th, u1 = (r[0] + r[2]) / tw, v1 = (r[1] + r[3]) / th;
      var cuv = [[u0, v0], [u1, v0], [u1, v1], [u0, v1]];
      order.forEach(function (k) { var c = f[2][k]; pos.push(c[0], c[1], c[2]); nrm.push(f[1][0], f[1][1], f[1][2]); uvs.push(cuv[k][0], cuv[k][1]); });
    });
    return { pos: new Float32Array(pos), nrm: new Float32Array(nrm), uv: new Float32Array(uvs) };
  }

  /* ------------------------------------------------------------ face decal (procedural default) */
  function drawDefaultFace(ctx) {
    ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.ellipse(46, 54, 7, 12, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(82, 54, 7, 12, 0, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.strokeStyle = '#000';
    ctx.beginPath(); ctx.arc(64, 62, 32, Math.PI * 0.18, Math.PI * 0.82); ctx.stroke();
  }

  /* ------------------------------------------------------------ renderer */
  var VS = 'attribute vec3 aPos;attribute vec3 aNrm;attribute vec2 aUV;uniform mat4 uMVP;uniform mat4 uNrm;varying vec2 vUV;varying vec3 vN;' +
    'void main(){gl_Position=uMVP*vec4(aPos,1.0);vUV=aUV;vN=(uNrm*vec4(aNrm,0.0)).xyz;}';
  var FS = 'precision mediump float;uniform sampler2D uTex;uniform vec4 uColor;uniform float uUseTex;varying vec2 vUV;varying vec3 vN;' +
    'void main(){vec4 c=uUseTex>0.5?texture2D(uTex,vUV):uColor;if(c.a<0.03)discard;' +
    'float d=max(dot(normalize(vN),normalize(vec3(0.35,0.65,0.75))),0.0);float l=0.52+0.5*d;gl_FragColor=vec4(c.rgb*l,c.a);}';

  function create(canvas, opts) {
    opts = opts || {};
    var gl = canvas.getContext('webgl', { alpha: true, premultipliedAlpha: false, antialias: true, preserveDrawingBuffer: true }) ||
      canvas.getContext('experimental-webgl', { alpha: true, premultipliedAlpha: false, preserveDrawingBuffer: true });
    if (!gl) return null;

    function sh(type, src) { var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }
    var prog = gl.createProgram(); gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    gl.useProgram(prog);
    var A = { pos: gl.getAttribLocation(prog, 'aPos'), nrm: gl.getAttribLocation(prog, 'aNrm'), uv: gl.getAttribLocation(prog, 'aUV') };
    var U = { mvp: gl.getUniformLocation(prog, 'uMVP'), nrm: gl.getUniformLocation(prog, 'uNrm'), tex: gl.getUniformLocation(prog, 'uTex'),
      color: gl.getUniformLocation(prog, 'uColor'), useTex: gl.getUniformLocation(prog, 'uUseTex') };
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    function buf(data) { var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); return b; }
    function makeMesh(d) { return { p: buf(d.pos), n: buf(d.nrm), u: buf(d.uv), count: d.pos.length / 3 }; }
    function makeTex(source) {
      var t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      return t;
    }

    /* static body geometry */
    var geo = {};
    PARTS.forEach(function (p) {
      var tw = p.head ? HEAD_TW : TW, th = p.head ? HEAD_TH : TH;
      geo[p.id] = makeMesh(boxData(p.size[0] / 2, p.size[1] / 2, p.size[2] / 2, p.uv, tw, th));
    });

    var state = { outfit: null, partTex: {}, acc: [], yaw: 0.35, pitch: 0.08, dist: 14.5, ty: 3.1, fov: 30, spin: !!opts.spin, raf: 0, dead: false };
    var accTexCache = {}, accMeshCache = {};

    function freeTextures() { Object.keys(state.partTex).forEach(function (k) { gl.deleteTexture(state.partTex[k]); }); state.partTex = {}; }

    function build(outfit, imgs) {
      freeTextures();
      var colors = Object.assign({}, DEFAULT_COLORS, outfit.colors || {});
      PARTS.forEach(function (p) {
        var cv = document.createElement('canvas'), ctx;
        if (p.head) {
          cv.width = HEAD_TW; cv.height = HEAD_TH; ctx = cv.getContext('2d');
          ctx.fillStyle = colors.head; ctx.fillRect(0, 0, HEAD_TW, HEAD_TH);
          ctx.save(); ctx.beginPath(); ctx.rect(0, 0, 128, 128); ctx.clip();
          if (imgs.face) ctx.drawImage(imgs.face, 0, 0, 128, 128); else drawDefaultFace(ctx);
          ctx.restore();
        } else {
          cv.width = TW; cv.height = TH; ctx = cv.getContext('2d');
          ctx.fillStyle = colors[p.id]; ctx.fillRect(0, 0, TW, TH);
          p.layers.forEach(function (layer) {
            var im = imgs[layer]; if (!im) return;
            if (layer === 'tshirt') { var r = UV_TORSO.front; ctx.drawImage(im, r[0], r[1], r[2], r[3]); }
            else ctx.drawImage(im, 0, 0, TW, TH);
          });
        }
        state.partTex[p.id] = makeTex(cv);
      });
    }

    function accessoryGPU(a, mesh, texImg) {
      var key = a.meshUrl;
      if (!accMeshCache[key]) accMeshCache[key] = makeMesh(mesh);
      var tex = null;
      if (texImg) { if (!accTexCache[a.textureUrl]) accTexCache[a.textureUrl] = makeTex(texImg); tex = accTexCache[a.textureUrl]; }
      var off = a.offset || {}, type = a.type || 'Hat', at = ATTACH[type] || ATTACH.Hat;
      var ext = Math.max(mesh.max[0] - mesh.min[0], mesh.max[1] - mesh.min[1], mesh.max[2] - mesh.min[2]) || 1;
      var s = a.scale > 0 ? a.scale : ((type === 'Hat' || type === 'Hair') ? 2.4 : 2.2) / ext;
      var cx = (mesh.min[0] + mesh.max[0]) / 2, cz = (mesh.min[2] + mesh.max[2]) / 2, cy = SIT_ON_BASE[type] ? mesh.min[1] : (mesh.min[1] + mesh.max[1]) / 2;
      var m = mul(trans(at[0] + (off.x || 0), at[1] + (off.y || 0), at[2] + (off.z || 0)), mul(rotY((a.rot || 0) * Math.PI / 180), mul(scal(s, s, s), trans(-cx, -cy, -cz))));
      return { mesh: accMeshCache[key], tex: tex, matrix: m, color: hexRGBA(a.color || '#b9bcc2') };
    }

    function set(outfit) {
      outfit = outfit || {}; state.outfit = outfit;
      var accs = (outfit.accessories || []).filter(function (a) { return a.meshUrl; });
      return Promise.all([
        loadImage(outfit.shirt), loadImage(outfit.pants), loadImage(outfit.tshirt), loadImage(outfit.face),
        Promise.all(accs.map(function (a) { return Promise.all([loadOBJ(a.meshUrl), loadImage(a.textureUrl)]); }))
      ]).then(function (r) {
        if (state.dead || state.outfit !== outfit) return;
        build(outfit, { shirt: r[0], pants: r[1], tshirt: r[2], face: r[3] });
        state.acc = [];
        accs.forEach(function (a, i) { var mesh = r[4][i][0]; if (mesh) state.acc.push(accessoryGPU(a, mesh, r[4][i][1])); });
        draw();
      });
    }

    function bindMesh(m) {
      gl.bindBuffer(gl.ARRAY_BUFFER, m.p); gl.enableVertexAttribArray(A.pos); gl.vertexAttribPointer(A.pos, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.n); gl.enableVertexAttribArray(A.nrm); gl.vertexAttribPointer(A.nrm, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.u); gl.enableVertexAttribArray(A.uv); gl.vertexAttribPointer(A.uv, 2, gl.FLOAT, false, 0, 0);
    }

    function draw(view) {
      if (state.dead) return;
      view = view || {};
      var w = canvas.width, h = canvas.height;
      gl.viewport(0, 0, w, h); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      if (!state.outfit) return;
      var yaw = view.yaw != null ? view.yaw : state.yaw, pitch = view.pitch != null ? view.pitch : state.pitch;
      var dist = view.dist || state.dist, ty = view.ty != null ? view.ty : state.ty, fov = (view.fov || state.fov) * Math.PI / 180;
      var rot = mul(rotX(pitch), rotY(Math.PI + yaw));
      var V = mul(trans(0, 0, -dist), mul(rot, trans(0, -ty, 0)));
      var P = persp(fov, w / h, 0.5, 80), PV = mul(P, V);
      var sc = state.outfit.scale || {}, bw = sc.w || 1, bh = sc.h || 1, hs = sc.head || 1;
      var B = scal(bw, bh, bw);
      gl.uniform1i(U.tex, 0); gl.uniformMatrix4fv(U.nrm, false, new Float32Array(rot));
      PARTS.forEach(function (p) {
        var s = p.head ? hs : 1, py = p.head ? 4 + 0.5 * hs : p.pos[1];
        var M = mul(B, mul(trans(p.pos[0], py, p.pos[2]), scal(s, s, s)));
        gl.uniformMatrix4fv(U.mvp, false, new Float32Array(mul(PV, M)));
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, state.partTex[p.id]); gl.uniform1f(U.useTex, 1);
        bindMesh(geo[p.id]); gl.drawArrays(gl.TRIANGLES, 0, geo[p.id].count);
      });
      state.acc.forEach(function (a) {
        var M = mul(B, a.matrix);
        gl.uniformMatrix4fv(U.mvp, false, new Float32Array(mul(PV, M)));
        if (a.tex) { gl.bindTexture(gl.TEXTURE_2D, a.tex); gl.uniform1f(U.useTex, 1); } else { gl.uniform1f(U.useTex, 0); gl.uniform4fv(U.color, a.color); }
        bindMesh(a.mesh); gl.drawArrays(gl.TRIANGLES, 0, a.mesh.count);
      });
    }

    /* interactive: drag to rotate, wheel to zoom, optional auto-spin */
    var drag = null;
    function down(e) { drag = { x: e.clientX, y: e.clientY, yaw: state.yaw, pitch: state.pitch }; state.spin = false; canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId); }
    function move(e) {
      if (!drag) return;
      state.yaw = drag.yaw + (e.clientX - drag.x) * 0.012;
      state.pitch = Math.max(-0.6, Math.min(0.9, drag.pitch + (e.clientY - drag.y) * 0.006)); draw();
    }
    function up() { drag = null; }
    function wheel(e) { e.preventDefault(); state.dist = Math.max(5, Math.min(24, state.dist + e.deltaY * 0.01)); draw(); }
    function loop() { if (state.dead) return; if (state.spin) { state.yaw += 0.012; draw(); } state.raf = requestAnimationFrame(loop); }
    var api = {
      set: set, draw: draw, state: state, canvas: canvas,
      interactive: function () {
        canvas.style.touchAction = 'none'; canvas.style.cursor = 'grab';
        canvas.addEventListener('pointerdown', down); canvas.addEventListener('pointermove', move);
        canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up); canvas.addEventListener('wheel', wheel, { passive: false });
        loop(); return api;
      },
      spin: function (on) { state.spin = !!on; },
      destroy: function () { state.dead = true; cancelAnimationFrame(state.raf); var x = gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); }
    };
    return api;
  }

  /* ------------------------------------------------------------ shared offscreen renderer for thumbnails */
  var shared = null, queue = Promise.resolve(), thumbCache = {};
  var MODES = { full: { dist: 14.5, ty: 3.1 }, bust: { dist: 6.4, ty: 3.9 }, head: { dist: 4.2, ty: 4.55 } };
  function thumb(outfit, o) {
    o = o || {}; var w = o.w || 200, h = o.h || 200, mode = MODES[o.mode || 'full'];
    var key = JSON.stringify([outfit, w, h, o.mode, o.yaw]);
    if (thumbCache[key]) return thumbCache[key];
    var p = queue.then(function () {
      if (!shared) { var c = document.createElement('canvas'); shared = create(c); }
      if (!shared) return null;
      shared.canvas.width = w; shared.canvas.height = h;
      return shared.set(outfit).then(function () {
        shared.draw({ yaw: o.yaw != null ? o.yaw : 0.3, pitch: 0.06, dist: mode.dist, ty: mode.ty });
        return shared.canvas.toDataURL('image/png');
      });
    }).catch(function () { return null; });
    queue = p.then(function () { }, function () { });
    thumbCache[key] = p; return p;
  }

  /* build an outfit from API data: colors + worn items (each has type, imageUrl, render{meshUrl,textureUrl,offset,scale,rot,color}) */
  function outfit(colors, worn) {
    var o = { colors: colors || {}, accessories: [], shirt: null, pants: null, tshirt: null, face: null };
    (worn || []).forEach(function (it) {
      var t = it.type;
      if (t === 'Shirt') o.shirt = it.imageUrl; else if (t === 'Pants') o.pants = it.imageUrl; else if (t === 'T-Shirt') o.tshirt = it.imageUrl; else if (t === 'Face') o.face = it.imageUrl;
      else if (it.render && it.render.meshUrl) {
        o.accessories.push({ type: t, meshUrl: it.render.meshUrl, textureUrl: it.render.textureUrl || null, offset: it.render.offset, scale: it.render.scale, rot: it.render.rot, color: it.render.color });
      }
    });
    return o;
  }

  var supported = (function () { try { var c = document.createElement('canvas'); return !!(c.getContext('webgl') || c.getContext('experimental-webgl')); } catch (e) { return false; } })();
  global.AvatarRenderer = { create: create, thumb: thumb, outfit: outfit, supported: supported, PALETTE: PALETTE, DEFAULT_COLORS: DEFAULT_COLORS, ATTACH: ATTACH };
})(window);
