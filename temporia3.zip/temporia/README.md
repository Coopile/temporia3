# Temporia

## Run it (Windows, cmd)
1. Node.js LTS (nodejs.org). `node -v` should say 18 or newer.
2. In this folder:  `node server.js`   (or double-click `start.bat`)
3. http://localhost:3000   -   admin panel: http://localhost:3000/admin

Update an existing install by extracting this zip over your folder. It does not contain `data/` or
`config.json`, so your users, items and settings are untouched (old databases are upgraded automatically).

## URLs
`/user/12` profile by user ID  -  `/item/7` item page  -  `/search?q=12` (people are searchable by name or ID)
`/catalog` `/games` `/donate` `/events` `/avatar` `/inventory` ...  Unknown pages show the 404 page.

## Avatars (public/avatar.js)
Own WebGL renderer, no libraries: classic R6 rig in studs, standard 585x559 shirt/pants template, T-shirt decal on the
torso, face decal, body colours, accessories from .obj meshes. Used on the avatar editor, profiles, item pages, sandbox
and admin placement preview.

Making an accessory (Admin > Items & Accessories):
- thumbnail image + the mesh as an `.obj` (optional texture image, or a flat colour)
- the mesh is auto-centred and auto-scaled; hats sit on top of the head. Use **Placement** on the item for live
  offset / scale / rotation tuning.
- `samples/top_hat.obj` is a small example mesh; `samples/clothing_template_guide.png` shows the clothing layout.

## Promo codes (Admin > Promo Codes)
Reward: Temps, Tix or an item. Optional max uses and a time limit in seconds/minutes/hours/days (counted from creation).
Each person can redeem a code once.

## Other admin tools
Give Temps / Tix / items (by username or user ID), Checkmarks (people with 100+ followers get one automatically),
Games page entries, bans, moderation, activity log.

## config.json
`admins` accepts usernames or emails, `emailWhitelist` limits sign-ups (empty = anyone), `host` / `port`.
Before going public: HTTPS, `"secureCookies": true`, back up `data/`.
