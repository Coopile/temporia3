@echo off
title Temporia server
cd /d "%~dp0"
node -v >nul 2>&1 || (echo Node.js is not installed. Get it from https://nodejs.org ^(LTS^) and run this again. & pause & exit /b)
node server.js
pause
