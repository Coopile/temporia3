'use strict';
/*
 * Temporia server - zero dependencies, just Node.js 18+.
 * Run:  node server.js     (or double-click start.bat)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { promisify } = require('util');
const scrypt = promisify(crypto.scrypt);

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');
const UPLOADS = path.join(DATA, 'uploads');   // item / asset thumbnails + textures
const FILES = path.join(DATA, 'assets');      // raw asset files (.obj meshes etc.)
[DATA, UPLOADS, FILES].forEach(d => fs.mkdirSync(d, { recursive: true }));

/* ------------------------------------------------------------------ config */
const CONFIG_FILE = path.join(ROOT, 'config.json');
const DEFAULTS = { port: 3000, host: '127.0.0.1', secureCookies: false, trustProxy: false, admins: [], emailWhitelist: [] };
if (!fs.existsSync(CONFIG_FILE)) fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULTS, null, 2));
let config = Object.assign({}, DEFAULTS);
try { Object.assign(config, JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'))); }
catch (e) { console.error('config.json is not valid JSON, using defaults:', e.message); }
const WHITELIST = (config.emailWhitelist || []).map(s => String(s).trim().toLowerCase()).filter(Boolean);
const CONFIG_ADMINS = (config.admins || []).map(s => String(s).trim().toLowerCase());
const isConfigAdmin = u => CONFIG_ADMINS.includes(String(u.usernameLower || '').toLowerCase()) || CONFIG_ADMINS.includes(String(u.email || '').toLowerCase().trim());

/* ---------------------------------------------------------------- database */
const DB_FILE = path.join(DATA, 'db.json');
let db = { users: [], items: [], sessions: {}, logs: [], settings: { announcement: 'Welcome to Temporia!' }, promoCodes: [], places: [], nextId: 1 };
if (fs.existsSync(DB_FILE)) {
  try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); }
  catch (e) { console.error('Could not read data/db.json:', e.message); process.exit(1); }
}
function save() {
  const tmp = DB_FILE + '.tmp';
  try { fs.writeFileSync(tmp, JSON.stringify(db)); fs.renameSync(tmp, DB_FILE); }
  catch (e) { try { fs.writeFileSync(DB_FILE, JSON.stringify(db)); } catch (e2) { console.error('SAVE FAILED', e2.message); } }
}
const nid = () => db.nextId++;

/* migrations: older databases get the new fields */
db.promoCodes = db.promoCodes || []; db.places = db.places || []; db.settings = db.settings || {};
db.users.forEach(u => {
  if (!Array.isArray(u.wearing)) u.wearing = [];
  if (!u.colors || typeof u.colors !== 'object') u.colors = {};
  if (!Array.isArray(u.following)) u.following = [];
  if (!Array.isArray(u.inventory)) u.inventory = [];
  if (typeof u.verified !== 'boolean') u.verified = false;
  if (isConfigAdmin(u)) u.role = 'admin';
});
db.promoCodes.forEach(p => {
  if (p.rewardType === 'currency') p.rewardType = 'temps';
  if (p.active === undefined) p.active = true;
  if (!p.id) p.id = nid();
  if (!p.createdAt) p.createdAt = Date.now();
  if (!Array.isArray(p.claimedBy)) p.claimedBy = [];
});
save();

/* ----------------------------------------------------------------- helpers */
const ITEM_TYPES = ['Hat', 'Hair', 'Face Accessory', 'Neck', 'Shoulder', 'Front', 'Back', 'Waist', 'Gear',
  'Head', 'Face', 'T-Shirt', 'Shirt', 'Pants', 'Torso', 'Package'];
const USER_TYPES = ['T-Shirt', 'Shirt', 'Pants'];          // what normal users may submit for moderation
const ACCESSORY_TYPES = ['Hat', 'Hair', 'Face Accessory', 'Neck', 'Shoulder', 'Front', 'Back', 'Waist'];
const MAX_ACCESSORIES = 3;
const ASSET_EXT = ['obj', 'mtl', 'mesh', 'rbxm', 'rbxmx', 'png', 'zip'];
const RESERVED = ['admin', 'administrator', 'moderator', 'mod', 'system', 'temporia', 'staff', 'support', 'owner'];
const PALETTE = ['#f2f3f3', '#e5e4df', '#a3a2a5', '#635f62', '#1b2a35', '#c4281c', '#da8541', '#f5cd30', '#fdea8d', '#a4bd47', '#4b974b', '#287f47',
  '#0d69ac', '#6e99ca', '#04afec', '#203a56', '#6b327c', '#e8bac8', '#d7c59a', '#cc8e69', '#a05f35', '#694028', '#ffcc99', '#74869d'];
const BODY_PARTS = ['head', 'torso', 'leftArm', 'rightArm', 'leftLeg', 'rightLeg'];
const UNIT_MS = { second: 1000, seconds: 1000, minute: 60000, minutes: 60000, hour: 3600000, hours: 3600000, day: 86400000, days: 86400000 };
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };

class HttpError extends Error { constructor(status, msg, extra) { super(msg); this.status = status; this.extra = extra; } }
const fail = (s, m, x) => { throw new HttpError(s, m, x); };

function send(res, status, obj, headers) {
  const body = JSON.stringify(obj);
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers || {}));
  res.end(body);
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'Upload too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(new HttpError(400, 'Invalid JSON')); }
    });
    req.on('error', reject);
  });
}
function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(p => {
    const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function clientIp(req) {
  if (config.trustProxy && req.headers['x-forwarded-for']) return String(req.headers['x-forwarded-for']).split(',')[0].trim();
  return req.socket.remoteAddress || 'unknown';
}
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now(); let h = hits.get(key);
  if (!h || now > h.reset) { h = { n: 0, reset: now + windowMs }; hits.set(key, h); }
  h.n++; return h.n > max;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (now > v.reset) hits.delete(k); }, 60000).unref();

async function hashPw(pw) {
  const salt = crypto.randomBytes(16);
  const h = await scrypt(pw, salt, 64);
  return salt.toString('hex') + ':' + h.toString('hex');
}
async function checkPw(pw, stored) {
  const [s, h] = String(stored).split(':');
  const hh = await scrypt(pw, Buffer.from(s, 'hex'), 64);
  const hb = Buffer.from(h, 'hex');
  return hb.length === hh.length && crypto.timingSafeEqual(hh, hb);
}
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const cleanText = (s, max) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);

/* ---------------------------------------------------------------- sessions */
const SESSION_MS = 14 * 24 * 3600 * 1000;
function startSession(res, user) {
  const token = crypto.randomBytes(32).toString('hex');
  db.sessions[sha(token)] = { uid: user.id, exp: Date.now() + SESSION_MS };
  user.lastLogin = Date.now(); save();
  setCookie(res, token, SESSION_MS / 1000);
}
function setCookie(res, token, maxAge) {
  res.setHeader('Set-Cookie', `tsid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}` + (config.secureCookies ? '; Secure' : ''));
}
function killSessions(uid) { for (const k of Object.keys(db.sessions)) if (db.sessions[k].uid === uid) delete db.sessions[k]; }
function isBanned(u) {
  if (!u.banned) return false;
  if (u.banned.until && Date.now() > u.banned.until) { u.banned = null; save(); return false; }
  return true;
}
function getUser(req) {
  const tok = parseCookies(req).tsid; if (!tok) return null;
  const s = db.sessions[sha(tok)]; if (!s) return null;
  if (Date.now() > s.exp) { delete db.sessions[sha(tok)]; return null; }
  const u = db.users.find(x => x.id === s.uid);
  if (!u || isBanned(u)) return null;
  if (!u.lastSeen || Date.now() - u.lastSeen > 60000) { u.lastSeen = Date.now(); save(); }
  return u;
}
const needUser = req => getUser(req) || fail(401, 'Please log in');
function needAdmin(req) { const u = needUser(req); if (u.role !== 'admin') fail(403, 'Admins only'); return u; }
const adminExists = () => db.users.some(u => u.role === 'admin');
function log(admin, action, target) {
  db.logs.unshift({ t: Date.now(), admin: admin.username, action, target });
  if (db.logs.length > 300) db.logs.length = 300; save();
}
/* find a user from "12", "#12" or "username" */
function findUser(ref) {
  const s = String(ref == null ? '' : ref).trim().replace(/^#/, ''); if (!s) return null;
  if (/^\d+$/.test(s)) { const byId = db.users.find(u => u.id === +s); if (byId) return byId; }
  return db.users.find(u => u.usernameLower === s.toLowerCase()) || null;
}

/* ----------------------------------------------------------- shape helpers */
const followersOf = id => db.users.reduce((n, x) => n + (x.following.includes(id) ? 1 : 0), 0);
const isVerified = u => !!u.verified || followersOf(u.id) >= 100;
const isOnline = u => !!u.lastSeen && Date.now() - u.lastSeen < 300000;
const ownUser = u => ({ id: u.id, username: u.username, email: u.email, role: u.role, balance: u.balance, tickets: u.tickets || 0,
  createdAt: u.createdAt, discordId: u.discordId, discordUsername: u.discordUsername, verified: isVerified(u),
  wearing: u.wearing, colors: u.colors, followers: followersOf(u.id), following: u.following.length });
const adminUser = u => ({ id: u.id, username: u.username, email: u.email, discordId: u.discordId, discordUsername: u.discordUsername,
  role: u.role, createdAt: u.createdAt, lastLogin: u.lastLogin || null, lastSeen: u.lastSeen || null, balance: u.balance, tickets: u.tickets || 0,
  items: (u.inventory || []).length, banned: isBanned(u) ? u.banned : null, verified: isVerified(u), manualVerified: !!u.verified, followers: followersOf(u.id) });
function renderInfo(it) {
  return {
    meshUrl: it.assetFile && /\.obj$/i.test(it.assetFile.file) ? '/api/items/' + it.id + '/mesh' : null,
    textureUrl: it.texture ? '/uploads/' + it.texture : null,
    offset: it.offset || { x: 0, y: 0, z: 0 }, scale: it.scale || 0, rot: it.rot || 0, color: it.color || null
  };
}
const creatorOf = it => it.creatorId ? db.users.find(u => u.id === it.creatorId) : null;
const pubItem = (it, owned, worn) => {
  const c = creatorOf(it);
  return { id: it.id, name: it.name, description: it.description, type: it.type, price: it.price,
    imageUrl: '/uploads/' + it.image, creator: it.creatorName || 'Temporia', creatorId: it.creatorId || null, creatorVerified: c ? isVerified(c) : true,
    createdAt: it.createdAt, owned: !!owned, worn: !!worn, onSale: it.onSale, sales: it.sales || 0, render: renderInfo(it) };
};
const adminItem = it => Object.assign(pubItem(it), { status: it.status, rejectReason: it.rejectReason || '',
  hasFile: !!it.assetFile, fileName: it.assetFile ? it.assetFile.orig : null });
function profileOf(u, viewer) {
  if (isBanned(u)) return { id: u.id, username: u.username, banned: true };
  return { id: u.id, username: u.username, createdAt: u.createdAt, verified: isVerified(u), role: u.role === 'admin' ? 'admin' : 'user',
    followers: followersOf(u.id), following: u.following.length, isFollowing: !!(viewer && viewer.following.includes(u.id)), online: isOnline(u),
    colors: u.colors, wearing: u.wearing.map(id => db.items.find(i => i.id === id)).filter(Boolean).map(i => pubItem(i, true, true)),
    itemsOwned: u.inventory.length, isMe: !!(viewer && viewer.id === u.id) };
}
const promoStatus = p => !p.active ? 'disabled' : (p.expiresAt && Date.now() > p.expiresAt) ? 'expired' : (p.maxUses > 0 && p.uses >= p.maxUses) ? 'used up' : 'active';
const adminPromo = p => ({ id: p.id, code: p.code, rewardType: p.rewardType, rewardValue: p.rewardValue, rewardName: p.rewardType === 'item' ? ((db.items.find(i => i.id === p.rewardValue) || {}).name || '(deleted item)') : null,
  maxUses: p.maxUses, uses: p.uses, createdAt: p.createdAt, expiresAt: p.expiresAt, status: promoStatus(p) });

/* ----------------------------------------------------------------- uploads */
function decodeImage(dataUrl, maxBytes) {
  if (typeof dataUrl !== 'string') fail(400, 'Image is required');
  const comma = dataUrl.indexOf(',');
  if (comma < 0 || !/^data:image\/(png|jpeg|gif|webp);base64$/.test(dataUrl.slice(0, comma))) fail(400, 'Image must be PNG, JPG, GIF or WEBP');
  const buf = Buffer.from(dataUrl.slice(comma + 1), 'base64');
  if (!buf.length) fail(400, 'Image is empty');
  if (buf.length > maxBytes) fail(400, 'Image is too large (max ' + Math.round(maxBytes / 1048576) + ' MB)');
  let ext = null;
  if (buf[0] === 0x89 && buf.slice(1, 4).toString() === 'PNG') ext = 'png';
  else if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) ext = 'jpg';
  else if (buf.slice(0, 4).toString() === 'GIF8') ext = 'gif';
  else if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') ext = 'webp';
  if (!ext) fail(400, 'That file is not a real image');
  return { buf, ext };
}
function storeImage(dataUrl, maxBytes) {
  const { buf, ext } = decodeImage(dataUrl, maxBytes);
  const name = crypto.randomBytes(16).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(UPLOADS, name), buf); return name;
}
function storeAssetFile(f) {
  if (!f) return null;
  const orig = String(f.name || 'asset').replace(/[^\w.\- ]/g, '_').slice(0, 80);
  const ext = (orig.split('.').pop() || '').toLowerCase();
  if (!ASSET_EXT.includes(ext)) fail(400, 'Asset file type not allowed (' + ASSET_EXT.join(', ') + ')');
  const raw = String(f.data || ''); const buf = Buffer.from(raw.slice(raw.indexOf(',') + 1), 'base64');
  if (!buf.length) fail(400, 'Asset file is empty');
  if (buf.length > 5 * 1048576) fail(400, 'Asset file too large (max 5 MB)');
  const name = crypto.randomBytes(16).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(FILES, name), buf);
  return { file: name, orig };
}
function delItemFiles(it) {
  try { fs.unlinkSync(path.join(UPLOADS, it.image)); } catch (e) {}
  if (it.texture) try { fs.unlinkSync(path.join(UPLOADS, it.texture)); } catch (e) {}
  if (it.assetFile) try { fs.unlinkSync(path.join(FILES, it.assetFile.file)); } catch (e) {}
}
function readPlacement(body, it) {
  const num = (v, d, lo, hi) => { const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };
  if (body.offset && typeof body.offset === 'object') it.offset = { x: num(body.offset.x, 0, -20, 20), y: num(body.offset.y, 0, -20, 20), z: num(body.offset.z, 0, -20, 20) };
  if (body.scale !== undefined) it.scale = num(body.scale, 0, 0, 100);
  if (body.rot !== undefined) it.rot = num(body.rot, 0, -360, 360);
  if (body.color !== undefined) it.color = /^#[0-9a-fA-F]{6}$/.test(String(body.color)) ? String(body.color) : null;
}
function makePromo(body, admin) {
  let code = cleanText(body.code, 30).toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!code) code = crypto.randomBytes(5).toString('hex').toUpperCase();
  if (code.length < 3) fail(400, 'Code must be at least 3 characters');
  if (db.promoCodes.some(p => p.code === code)) fail(409, 'That code already exists');
  let rewardType = String(body.rewardType || 'temps'); if (rewardType === 'currency') rewardType = 'temps';
  if (!['temps', 'tix', 'item'].includes(rewardType)) fail(400, 'Reward must be Temps, Tix or an item');
  const rewardValue = Math.floor(Number(body.rewardValue));
  if (!(rewardValue >= 1)) fail(400, rewardType === 'item' ? 'Enter the item ID' : 'Enter an amount of 1 or more');
  if (rewardType !== 'item' && rewardValue > 10000000) fail(400, 'Amount is too large');
  if (rewardType === 'item' && !db.items.some(i => i.id === rewardValue && i.status === 'approved')) fail(404, 'No approved item with that ID');
  const maxUses = Math.max(0, Math.floor(Number(body.maxUses || 0)));
  let ms = 0;
  if (body.activeSeconds) ms = Math.floor(Number(body.activeSeconds)) * 1000;            // older field name
  else if (Number(body.durationValue) > 0) {
    const u = UNIT_MS[String(body.durationUnit || 'hours').toLowerCase()]; if (!u) fail(400, 'Unit must be seconds, minutes, hours or days');
    ms = Math.floor(Number(body.durationValue)) * u;
  }
  if (ms < 0 || ms > 3650 * 86400000) fail(400, 'That time limit is out of range');
  const p = { id: nid(), code, rewardType, rewardValue, maxUses, uses: 0, createdAt: Date.now(), expiresAt: ms > 0 ? Date.now() + ms : null, active: true, claimedBy: [] };
  db.promoCodes.push(p); save(); log(admin, 'created promo code', code);
  return p;
}

/* ------------------------------------------------------------------- API */
async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  let body = {};
  if (m === 'POST') {
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) fail(415, 'JSON only');
    body = await readBody(req, 14 * 1048576);
  }
  let g;

  /* ---- public ---- */
  if (m === 'GET' && p === '/api/stats') return send(res, 200, { users: db.users.length, announcement: db.settings.announcement || '' });
  if (m === 'GET' && p === '/api/me') { const u = getUser(req); return send(res, 200, { user: u ? ownUser(u) : null }); }
  if (m === 'GET' && p === '/api/places') return send(res, 200, { places: db.places.map(x => ({ id: x.id, name: x.name, imageUrl: '/uploads/' + x.image, creator: x.creator, playing: x.playing || 0 })) });

  if (m === 'POST' && p === '/api/signup') {
    if (limited('su:' + clientIp(req), 8, 3600000)) fail(429, 'Too many sign-ups from this connection. Try again later.');
    const username = cleanText(body.username, 20), email = cleanText(body.email, 254).toLowerCase();
    const password = String(body.password || '');
    let dUser = cleanText(body.discordUsername, 37).replace(/^@/, ''), dId = cleanText(body.discordId, 20);
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) fail(400, 'Username must be 3-20 letters, numbers or underscores');
    if (!/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/.test(email)) fail(400, 'Enter a valid email address');
    if (WHITELIST.length && !WHITELIST.some(w => w === email || (w[0] === '@' && email.endsWith(w)))) fail(403, 'Sign-ups are limited to approved email addresses');
    if (password.length < 8 || password.length > 128) fail(400, 'Password must be 8-128 characters');
    if (!/^[A-Za-z0-9_.#]{2,37}$/.test(dUser)) fail(400, 'Enter your Discord username');
    if (!/^\d{17,20}$/.test(dId)) fail(400, 'Discord ID must be 17-20 digits (Discord > Settings > Advanced > Developer Mode, then right-click yourself > Copy User ID)');
    const lower = username.toLowerCase();
    const willBeAdmin = isConfigAdmin({ usernameLower: lower, email }) || !adminExists();
    if (RESERVED.includes(lower) && !willBeAdmin) fail(400, 'That username is reserved');
    if (db.users.some(u => u.usernameLower === lower)) fail(409, 'That username is taken');
    if (db.users.some(u => u.email === email)) fail(409, 'That email is already registered');
    if (db.users.some(u => u.discordId === dId)) fail(409, 'That Discord ID is already linked to an account');
    const user = { id: nid(), username, usernameLower: lower, email, passHash: await hashPw(password), discordId: dId, discordUsername: dUser,
      role: willBeAdmin ? 'admin' : 'user', balance: 100, tickets: 0, inventory: [], wearing: [], colors: {}, following: [], verified: false,
      createdAt: Date.now(), banned: null };
    db.users.push(user); save();
    if (willBeAdmin) console.log('  * "' + username + '" was made an ADMIN (first account / listed in config.json).');
    startSession(res, user);
    return send(res, 200, { user: ownUser(user) });
  }

  if (m === 'POST' && p === '/api/login') {
    const id = cleanText(body.username, 254).toLowerCase(), password = String(body.password || '');
    const key = 'li:' + clientIp(req) + ':' + id;
    if (limited(key, 8, 600000)) fail(429, 'Too many attempts. Wait 10 minutes and try again.');
    const user = db.users.find(u => u.usernameLower === id || u.email === id);
    const ok = user && await checkPw(password, user.passHash);
    if (!ok) fail(401, 'Invalid username or password');
    if (isBanned(user)) fail(403, 'banned', { reason: user.banned.reason, until: user.banned.until });
    hits.delete(key); startSession(res, user);
    return send(res, 200, { user: ownUser(user) });
  }
  if (m === 'POST' && p === '/api/logout') {
    const tok = parseCookies(req).tsid; if (tok) { delete db.sessions[sha(tok)]; save(); }
    setCookie(res, '', 0); return send(res, 200, { ok: true });
  }

  /* ---- catalog / items ---- */
  if (m === 'GET' && p === '/api/items') {
    const u = getUser(req); const type = url.searchParams.get('type') || '', q = (url.searchParams.get('q') || '').toLowerCase();
    const items = db.items.filter(i => i.status === 'approved' && i.onSale && (!type || i.type === type) && (!q || i.name.toLowerCase().includes(q)))
      .sort((a, b) => b.createdAt - a.createdAt).map(i => pubItem(i, u && u.inventory.includes(i.id), u && u.wearing.includes(i.id)));
    return send(res, 200, { items });
  }
  if (m === 'GET' && (g = p.match(/^\/api\/items\/(\d+)$/))) {
    const u = getUser(req); const it = db.items.find(i => i.id === +g[1]);
    const allowed = it && (it.status === 'approved' || (u && (u.role === 'admin' || u.id === it.creatorId)));
    if (!allowed) fail(404, 'Item not found');
    const c = creatorOf(it);
    return send(res, 200, { item: Object.assign(pubItem(it, u && u.inventory.includes(it.id), u && u.wearing.includes(it.id)),
      { status: it.status, creator: it.creatorName || 'Temporia', creatorUser: c ? { id: c.id, username: c.username, verified: isVerified(c) } : null }) });
  }
  if (m === 'GET' && (g = p.match(/^\/api\/items\/(\d+)\/mesh$/))) {
    const u = getUser(req); const it = db.items.find(i => i.id === +g[1]);
    if (!it || !it.assetFile || !/\.obj$/i.test(it.assetFile.file) || !(it.status === 'approved' || (u && u.role === 'admin'))) fail(404, 'No mesh');
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'public, max-age=300', 'X-Content-Type-Options': 'nosniff' });
    return fs.createReadStream(path.join(FILES, it.assetFile.file)).pipe(res);
  }

  /* ---- search (people / catalog / clothes / games) ---- */
  if (m === 'GET' && p === '/api/search') {
    const q = (url.searchParams.get('q') || '').toLowerCase().trim();
    const type = url.searchParams.get('type') || 'people';
    if (!q) return send(res, 200, []);
    let out = [];
    if (type === 'people') {
      const idq = /^#?\d+$/.test(q) ? +q.replace('#', '') : null;
      out = db.users.filter(x => !isBanned(x) && (x.usernameLower.includes(q) || x.id === idq)).slice(0, 24)
        .map(x => ({ id: x.id, username: x.username, online: isOnline(x), verified: isVerified(x), followers: followersOf(x.id) }));
    } else if (type === 'catalog') {
      out = db.items.filter(i => i.status === 'approved' && !USER_TYPES.includes(i.type) && i.name.toLowerCase().includes(q)).slice(0, 24)
        .map(i => ({ id: i.id, name: i.name, price: i.price, type: i.type, imageUrl: '/uploads/' + i.image, creator: i.creatorName || 'Temporia' }));
    } else if (type === 'clothes') {
      out = db.items.filter(i => i.status === 'approved' && USER_TYPES.includes(i.type) && i.name.toLowerCase().includes(q)).slice(0, 24)
        .map(i => ({ id: i.id, name: i.name, price: i.price, type: i.type, imageUrl: '/uploads/' + i.image, creator: i.creatorName || 'Temporia' }));
    } else if (type === 'games') {
      out = db.places.filter(x => x.name.toLowerCase().includes(q)).slice(0, 24).map(x => ({ id: x.id, name: x.name, imageUrl: '/uploads/' + x.image, creator: x.creator }));
    }
    return send(res, 200, out);
  }

  /* ---- profiles / follow ---- */
  if (m === 'GET' && (g = p.match(/^\/api\/users\/(\d+)$/))) {
    const t = db.users.find(x => x.id === +g[1]); if (!t) fail(404, 'User not found');
    return send(res, 200, { user: profileOf(t, getUser(req)) });
  }
  if (m === 'GET' && (g = p.match(/^\/api\/users\/(\d+)\/(followers|following)$/))) {
    const t = db.users.find(x => x.id === +g[1]); if (!t) fail(404, 'User not found');
    const list = g[2] === 'followers' ? db.users.filter(x => x.following.includes(t.id)) : t.following.map(id => db.users.find(x => x.id === id)).filter(Boolean);
    return send(res, 200, { users: list.filter(x => !isBanned(x)).slice(0, 200).map(x => ({ id: x.id, username: x.username, verified: isVerified(x), online: isOnline(x) })) });
  }
  if (m === 'GET' && (g = p.match(/^\/api\/users\/(\d+)\/creations$/))) {
    const t = db.users.find(x => x.id === +g[1]); if (!t || isBanned(t)) fail(404, 'User not found');
    return send(res, 200, { items: db.items.filter(i => i.creatorId === t.id && i.status === 'approved').sort((a, b) => b.createdAt - a.createdAt).map(i => pubItem(i)) });
  }
  if (m === 'POST' && (g = p.match(/^\/api\/users\/(\d+)\/follow$/))) {
    const u = needUser(req); const t = db.users.find(x => x.id === +g[1]);
    if (!t || isBanned(t)) fail(404, 'User not found');
    if (t.id === u.id) fail(400, "You can't follow yourself");
    const has = u.following.includes(t.id);
    if (body.follow !== false && !has) u.following.push(t.id);
    if (body.follow === false && has) u.following = u.following.filter(id => id !== t.id);
    save(); return send(res, 200, { isFollowing: u.following.includes(t.id), followers: followersOf(t.id), verified: isVerified(t) });
  }

  /* ---- logged-in ---- */
  if (m === 'POST' && (g = p.match(/^\/api\/items\/(\d+)\/buy$/))) {
    const u = needUser(req); const it = db.items.find(i => i.id === +g[1]);
    if (!it || it.status !== 'approved' || !it.onSale) fail(404, 'Item not available');
    if (u.inventory.includes(it.id)) fail(409, 'You already own this item');
    if (u.balance < it.price) fail(402, 'Not enough Temps');
    u.balance -= it.price; u.inventory.push(it.id); it.sales = (it.sales || 0) + 1;
    if (it.creatorId) { const c = db.users.find(x => x.id === it.creatorId); if (c) c.balance += it.price; }   // creator earns the full price
    save();
    return send(res, 200, { balance: u.balance, item: pubItem(it, true, u.wearing.includes(it.id)) });
  }
  if (m === 'GET' && p === '/api/inventory') {
    const u = needUser(req);
    return send(res, 200, { items: u.inventory.map(id => db.items.find(i => i.id === id)).filter(Boolean).map(i => pubItem(i, true, u.wearing.includes(i.id))) });
  }
  if (m === 'POST' && p === '/api/wear') {
    const u = needUser(req); const it = db.items.find(i => i.id === +body.itemId);
    if (!it || !u.inventory.includes(it.id)) fail(404, 'You do not own that item');
    if (it.status !== 'approved') fail(400, 'That item is not available');
    const on = body.wear !== false;
    u.wearing = u.wearing.filter(id => id !== it.id);
    if (on) {
      if (ACCESSORY_TYPES.includes(it.type)) {
        const count = u.wearing.map(id => db.items.find(i => i.id === id)).filter(i => i && ACCESSORY_TYPES.includes(i.type)).length;
        if (count >= MAX_ACCESSORIES) fail(400, 'You can wear up to ' + MAX_ACCESSORIES + ' accessories - take one off first');
      } else {
        u.wearing = u.wearing.filter(id => { const o = db.items.find(i => i.id === id); return o && o.type !== it.type; });   // one per slot
      }
      u.wearing.push(it.id);
    }
    save(); return send(res, 200, { wearing: u.wearing });
  }
  if (m === 'POST' && p === '/api/avatar') {
    const u = needUser(req); const c = body.colors || {};
    BODY_PARTS.forEach(part => { if (c[part] !== undefined) { if (!PALETTE.includes(String(c[part]).toLowerCase())) fail(400, 'Unknown colour'); u.colors[part] = String(c[part]).toLowerCase(); } });
    save(); return send(res, 200, { colors: u.colors });
  }
  if (m === 'POST' && p === '/api/assets') {
    const u = needUser(req);
    if (limited('as:' + u.id, 10, 3600000)) fail(429, 'Slow down - too many uploads this hour');
    if (db.items.filter(i => i.creatorId === u.id && i.status === 'pending').length >= 5) fail(400, 'You already have 5 assets waiting for review');
    const name = cleanText(body.name, 50), type = String(body.type || '');
    if (name.length < 2) fail(400, 'Give your asset a name');
    if (!USER_TYPES.includes(type)) fail(400, 'Choose Shirt, T-Shirt or Pants');
    const image = storeImage(body.image, 2 * 1048576);
    const it = { id: nid(), name, description: cleanText(body.description, 300), type, price: 0, image, assetFile: null, creatorId: u.id,
      creatorName: u.username, status: 'pending', rejectReason: '', onSale: false, createdAt: Date.now(), sales: 0 };
    db.items.push(it); save(); return send(res, 200, { item: adminItem(it) });
  }
  if (m === 'GET' && p === '/api/my-assets') {
    const u = needUser(req);
    return send(res, 200, { items: db.items.filter(i => i.creatorId === u.id).sort((a, b) => b.createdAt - a.createdAt).map(adminItem) });
  }
  if (m === 'POST' && (p === '/api/promocodes/redeem' || p === '/api/promo/redeem')) {
    const u = needUser(req);
    if (limited('pr:' + u.id, 15, 600000)) fail(429, 'Too many tries. Wait a few minutes.');
    const code = cleanText(body.code, 30).toUpperCase().replace(/[^A-Z0-9]/g, '');
    const promo = db.promoCodes.find(x => x.code === code);
    if (!code || !promo || !promo.active) fail(404, 'Invalid or unrecognized promo code');
    if (promo.claimedBy.includes(u.id)) fail(409, 'You have already redeemed this promo code');
    if (promo.expiresAt && Date.now() > promo.expiresAt) fail(410, 'This promo code has expired');
    if (promo.maxUses > 0 && promo.uses >= promo.maxUses) fail(410, 'This promo code has reached its usage limit');
    let message;
    if (promo.rewardType === 'item') {
      const it = db.items.find(i => i.id === promo.rewardValue);
      if (!it) fail(410, 'The reward for this code no longer exists');
      if (u.inventory.includes(it.id)) fail(409, 'You already own the reward item');
      u.inventory.push(it.id); message = 'You received the item "' + it.name + '"! Check your Inventory.';
    } else if (promo.rewardType === 'tix') { u.tickets = (u.tickets || 0) + promo.rewardValue; message = 'You received ' + promo.rewardValue + ' Tix!'; }
    else { u.balance += promo.rewardValue; message = 'You received ' + promo.rewardValue + ' T$!'; }
    promo.uses++; promo.claimedBy.push(u.id); save();
    return send(res, 200, { message, balance: u.balance, tickets: u.tickets || 0 });
  }
  if (m === 'POST' && p === '/api/change-password') {
    const u = needUser(req);
    if (!(await checkPw(String(body.current || ''), u.passHash))) fail(403, 'Current password is wrong');
    const np = String(body.password || ''); if (np.length < 8 || np.length > 128) fail(400, 'New password must be 8-128 characters');
    u.passHash = await hashPw(np);
    const keep = parseCookies(req).tsid; killSessions(u.id);
    if (keep) db.sessions[sha(keep)] = { uid: u.id, exp: Date.now() + SESSION_MS };
    save(); return send(res, 200, { ok: true });
  }

  /* ---- admin ---- */
  if (p.startsWith('/api/admin/')) {
    const admin = needAdmin(req);

    if (m === 'GET' && p === '/api/admin/stats') {
      const now = Date.now(), day = 86400000;
      return send(res, 200, {
        users: db.users.length, admins: db.users.filter(u => u.role === 'admin').length,
        banned: db.users.filter(isBanned).length, online: db.users.filter(u => u.lastSeen && now - u.lastSeen < 300000).length,
        newToday: db.users.filter(u => now - u.createdAt < day).length,
        pending: db.items.filter(i => i.status === 'pending').length, approved: db.items.filter(i => i.status === 'approved').length,
        rejected: db.items.filter(i => i.status === 'rejected').length, announcement: db.settings.announcement || '', types: ITEM_TYPES,
        promos: db.promoCodes.filter(x => promoStatus(x) === 'active').length
      });
    }
    if (m === 'GET' && p === '/api/admin/users') {
      const q = (url.searchParams.get('q') || '').toLowerCase();
      const users = db.users.filter(u => !q || [u.username, u.email, u.discordId, u.discordUsername, String(u.id)].some(v => String(v).toLowerCase().includes(q)))
        .sort((a, b) => b.createdAt - a.createdAt).map(adminUser);
      return send(res, 200, { users, total: db.users.length });
    }
    if (m === 'POST' && (g = p.match(/^\/api\/admin\/users\/(\d+)\/(ban|unban|role|reset-password)$/))) {
      const u = db.users.find(x => x.id === +g[1]); if (!u) fail(404, 'No such user');
      const act = g[2];
      if (act === 'ban') {
        if (u.id === admin.id) fail(400, "You can't ban yourself");
        if (u.role === 'admin') fail(400, 'Remove admin rights first');
        const days = Number(body.days) || 0;
        u.banned = { reason: cleanText(body.reason, 200) || 'No reason given', at: Date.now(), by: admin.username, until: days > 0 ? Date.now() + days * 86400000 : null };
        killSessions(u.id); save(); log(admin, 'ban' + (days > 0 ? ' (' + days + 'd)' : ' (permanent)'), u.username + ': ' + u.banned.reason);
      } else if (act === 'unban') {
        u.banned = null; save(); log(admin, 'unban', u.username);
      } else if (act === 'role') {
        const role = body.role === 'admin' ? 'admin' : 'user';
        if (u.id === admin.id && role !== 'admin') fail(400, "You can't remove your own admin rights");
        if (role === 'admin' && isBanned(u)) fail(400, 'Unban this user first');
        u.role = role; save(); log(admin, 'role -> ' + role, u.username);
      } else {
        const temp = crypto.randomBytes(8).toString('base64').replace(/[^A-Za-z0-9]/g, '').slice(0, 10) + crypto.randomInt(10, 99);
        u.passHash = await hashPw(temp); killSessions(u.id); save(); log(admin, 'reset password', u.username);
        return send(res, 200, { tempPassword: temp });
      }
      return send(res, 200, { user: adminUser(u) });
    }
    if (m === 'POST' && p === '/api/admin/announcement') {
      db.settings.announcement = cleanText(body.text, 160); save(); log(admin, 'announcement', db.settings.announcement);
      return send(res, 200, { ok: true });
    }

    /* give currency / items */
    if (m === 'POST' && p === '/api/admin/give') {
      const u = findUser(body.user); if (!u) fail(404, 'No user found for "' + cleanText(body.user, 40) + '"');
      const temps = Math.floor(Number(body.temps || 0)), tix = Math.floor(Number(body.tix || 0)), itemId = body.itemId ? Math.floor(Number(body.itemId)) : 0;
      if (!temps && !tix && !itemId) fail(400, 'Enter an amount of Temps, Tix or an item ID');
      if (Math.abs(temps) > 10000000 || Math.abs(tix) > 10000000) fail(400, 'Amount is too large');
      if (u.balance + temps < 0 || (u.tickets || 0) + tix < 0) fail(400, 'That would make the balance negative');
      let item = null;
      if (itemId) { item = db.items.find(i => i.id === itemId); if (!item) fail(404, 'No item with that ID'); if (u.inventory.includes(itemId)) fail(409, 'They already own that item'); }
      u.balance += temps; u.tickets = (u.tickets || 0) + tix; if (item) u.inventory.push(item.id);
      save(); log(admin, 'gave', u.username + ' (#' + u.id + '): ' + [temps && temps + ' T$', tix && tix + ' Tix', item && 'item ' + item.name].filter(Boolean).join(', '));
      return send(res, 200, { user: adminUser(u) });
    }

    /* verified checkmarks */
    if (m === 'GET' && p === '/api/admin/verified') {
      return send(res, 200, { users: db.users.filter(u => u.verified).map(adminUser) });
    }
    if (m === 'POST' && p === '/api/admin/verify') {
      const u = findUser(body.user); if (!u) fail(404, 'No user found for "' + cleanText(body.user, 40) + '"');
      u.verified = body.verified !== false; save(); log(admin, u.verified ? 'gave checkmark' : 'removed checkmark', u.username);
      return send(res, 200, { user: adminUser(u) });
    }

    /* promo codes */
    if (m === 'GET' && p === '/api/admin/promos') return send(res, 200, { promos: db.promoCodes.slice().sort((a, b) => b.createdAt - a.createdAt).map(adminPromo) });
    if (m === 'POST' && (p === '/api/admin/promos' || p === '/api/admin/promocodes')) { const pr = makePromo(body, admin); return send(res, 200, { ok: true, promo: adminPromo(pr), code: pr.code }); }
    if (m === 'POST' && (g = p.match(/^\/api\/admin\/promos\/(\d+)\/(toggle|delete)$/))) {
      const pr = db.promoCodes.find(x => x.id === +g[1]); if (!pr) fail(404, 'No such code');
      if (g[2] === 'toggle') { pr.active = !pr.active; log(admin, pr.active ? 'enabled promo' : 'disabled promo', pr.code); }
      else { db.promoCodes = db.promoCodes.filter(x => x !== pr); log(admin, 'deleted promo', pr.code); }
      save(); return send(res, 200, { ok: true });
    }

    /* games (places shown on the Games page) */
    if (m === 'GET' && p === '/api/admin/places') return send(res, 200, { places: db.places.map(x => ({ id: x.id, name: x.name, imageUrl: '/uploads/' + x.image, creator: x.creator, playing: x.playing || 0 })) });
    if (m === 'POST' && p === '/api/admin/places') {
      const name = cleanText(body.name, 50); if (name.length < 2) fail(400, 'Name is required');
      const image = storeImage(body.image, 3 * 1048576);
      const pl = { id: nid(), name, image, creator: cleanText(body.creator, 30) || 'Temporia', playing: Math.max(0, Math.floor(Number(body.playing) || 0)) };
      db.places.push(pl); save(); log(admin, 'added game', name); return send(res, 200, { ok: true });
    }
    if (m === 'POST' && (g = p.match(/^\/api\/admin\/places\/(\d+)\/delete$/))) {
      const pl = db.places.find(x => x.id === +g[1]); if (!pl) fail(404, 'No such game');
      try { fs.unlinkSync(path.join(UPLOADS, pl.image)); } catch (e) {}
      db.places = db.places.filter(x => x !== pl); save(); log(admin, 'deleted game', pl.name); return send(res, 200, { ok: true });
    }

    /* items / moderation */
    if (m === 'GET' && p === '/api/admin/items') {
      const st = url.searchParams.get('status') || '';
      const items = db.items.filter(i => !st || i.status === st).sort((a, b) => b.createdAt - a.createdAt).map(adminItem);
      return send(res, 200, { items });
    }
    if (m === 'POST' && p === '/api/admin/items') {           // official item / accessory upload
      const name = cleanText(body.name, 50), type = String(body.type || ''), price = Math.floor(Number(body.price));
      if (name.length < 2) fail(400, 'Name is required');
      if (!ITEM_TYPES.includes(type)) fail(400, 'Pick a valid type');
      if (!(price >= 0 && price <= 1000000)) fail(400, 'Price must be 0 - 1,000,000');
      const image = storeImage(body.image, 3 * 1048576);
      const texture = body.texture ? storeImage(body.texture, 3 * 1048576) : null;
      const assetFile = storeAssetFile(body.assetFile);
      const it = { id: nid(), name, description: cleanText(body.description, 300), type, price, image, texture, assetFile, creatorId: null,
        creatorName: 'Temporia', status: 'approved', rejectReason: '', onSale: body.onSale !== false, createdAt: Date.now(), sales: 0 };
      readPlacement(body, it);
      db.items.push(it); save(); log(admin, 'uploaded item', it.name + ' (' + type + ')');
      return send(res, 200, { item: adminItem(it) });
    }
    if (m === 'POST' && (g = p.match(/^\/api\/admin\/items\/(\d+)\/(approve|reject|delete|update)$/))) {
      const it = db.items.find(i => i.id === +g[1]); if (!it) fail(404, 'No such item');
      const act = g[2];
      if (act === 'approve') {
        const price = body.price === undefined ? it.price : Math.floor(Number(body.price));
        if (!(price >= 0 && price <= 1000000)) fail(400, 'Bad price');
        it.status = 'approved'; it.rejectReason = ''; it.price = price; it.onSale = true; save(); log(admin, 'approved asset', it.name + ' by ' + it.creatorName);
      } else if (act === 'reject') {
        it.status = 'rejected'; it.onSale = false; it.rejectReason = cleanText(body.reason, 200) || 'Does not meet the rules'; save();
        db.users.forEach(u => { u.wearing = u.wearing.filter(id => id !== it.id); });
        log(admin, 'rejected asset', it.name + ' by ' + it.creatorName + ': ' + it.rejectReason);
      } else if (act === 'update') {
        if (body.price !== undefined) { const pr = Math.floor(Number(body.price)); if (!(pr >= 0 && pr <= 1000000)) fail(400, 'Bad price'); it.price = pr; }
        if (body.onSale !== undefined) it.onSale = !!body.onSale;
        if (body.name !== undefined) { const n = cleanText(body.name, 50); if (n.length < 2) fail(400, 'Bad name'); it.name = n; }
        readPlacement(body, it);
        save(); log(admin, 'edited item', it.name);
      } else {
        db.items = db.items.filter(i => i !== it);
        db.users.forEach(u => { u.inventory = (u.inventory || []).filter(id => id !== it.id); u.wearing = (u.wearing || []).filter(id => id !== it.id); });
        db.promoCodes = db.promoCodes.filter(x => !(x.rewardType === 'item' && x.rewardValue === it.id));
        delItemFiles(it); save(); log(admin, 'deleted item', it.name);
        return send(res, 200, { ok: true });
      }
      return send(res, 200, { item: adminItem(it) });
    }
    if (m === 'GET' && (g = p.match(/^\/api\/admin\/items\/(\d+)\/file$/))) {
      const it = db.items.find(i => i.id === +g[1]);
      if (!it || !it.assetFile) fail(404, 'No file');
      const fp = path.join(FILES, it.assetFile.file);
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="' + it.assetFile.orig + '"', 'X-Content-Type-Options': 'nosniff' });
      return fs.createReadStream(fp).pipe(res);
    }
    if (m === 'GET' && p === '/api/admin/logs') return send(res, 200, { logs: db.logs.slice(0, 100) });
  }
  fail(404, 'Not found');
}

/* ---------------------------------------------------------------- static / error pages */
const ERROR_TEXT = { 400: 'Bad request', 403: 'Access denied', 404: 'Page Not Found', 405: 'Method not allowed', 500: 'Server error' };
const ERROR_TITLE = { 400: 'That request was not valid', 403: 'You do not have access to this page', 404: 'Page cannot be found or no longer exists', 405: 'That is not allowed here', 500: 'Something went wrong on our side' };
function sendError(res, code) {
  let html;
  try { html = fs.readFileSync(path.join(PUBLIC, 'error.html'), 'utf8'); } catch (e) { html = '<h1>{{CODE}} {{TEXT}}</h1>'; }
  html = html.replace(/\{\{CODE\}\}/g, String(code)).replace(/\{\{TEXT\}\}/g, ERROR_TEXT[code] || 'Error').replace(/\{\{TITLE\}\}/g, ERROR_TITLE[code] || 'Something went wrong');
  res.writeHead(code, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(html);
}
function sendFile(res, fp, extra) {
  fs.stat(fp, (err, st) => {
    if (err || !st.isFile()) return sendError(res, 404);
    res.writeHead(200, Object.assign({ 'Content-Type': MIME[path.extname(fp).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size, 'X-Content-Type-Options': 'nosniff' }, extra || {}));
    fs.createReadStream(fp).pipe(res);
  });
}
const spaPage = res => sendFile(res, path.join(PUBLIC, 'index.html'), { 'Cache-Control': 'no-store' });
function serveStatic(req, res, url) {
  let p; try { p = decodeURIComponent(url.pathname); } catch (e) { return sendError(res, 400); }
  if (p === '/') return spaPage(res);
  if (p === '/admin' || p === '/admin/') {
    const u = getUser(req);
    if (!u || u.role !== 'admin') { res.writeHead(302, { Location: '/' }); return res.end(); }
    return sendFile(res, path.join(PUBLIC, 'admin.html'), { 'Cache-Control': 'no-store' });
  }
  if (p === '/admin.html' || p === '/error.html' || p === '/index.html') { res.writeHead(302, { Location: p === '/admin.html' ? '/admin' : '/' }); return res.end(); }
  if (p.startsWith('/uploads/')) {
    const f = p.slice(9); if (!/^[a-f0-9]{32}\.(png|jpg|gif|webp)$/.test(f)) return sendError(res, 404);
    return sendFile(res, path.join(UPLOADS, f), { 'Cache-Control': 'public, max-age=86400' });
  }
  /* pretty URLs handled by the app: /user/12, /item/7, /catalog, /games ... (the page shows its own 404 if the thing doesn't exist) */
  if (!path.extname(p)) return spaPage(res);
  const fp = path.normalize(path.join(PUBLIC, p));
  if (!fp.startsWith(PUBLIC + path.sep)) return sendError(res, 403);
  sendFile(res, fp, { 'Cache-Control': p.endsWith('.html') ? 'no-store' : 'public, max-age=300' });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendError(res, 405);
    serveStatic(req, res, url);
  } catch (e) {
    if (e instanceof HttpError) { if (!res.headersSent) send(res, e.status, Object.assign({ error: e.message }, e.extra || {})); }
    else { console.error(e); if (!res.headersSent) send(res, 500, { error: 'Server error' }); }
  }
});
server.listen(config.port, config.host, () => {
  console.log('\n  Temporia is running:  http://localhost:' + config.port);
  if (!adminExists()) console.log('  No admin yet - the FIRST account you sign up becomes the admin.');
  if (WHITELIST.length) console.log('  Email whitelist ON (' + WHITELIST.length + ' entries) - only those emails can sign up.');
  console.log('  Admin panel:          http://localhost:' + config.port + '/admin');
  console.log('  Press Ctrl+C to stop.\n');
});
server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error('Port ' + config.port + ' is already in use. Change "port" in config.json.');
  else console.error(e);
  process.exit(1);
});
